import random
from flask import Flask, render_template, redirect, session, request
from datetime import datetime 

app = Flask(__name__)

app.secret_key = "alpha"

@app.route('/')
def make_money():

    if "activity" not in session:
        session["activity"] = []
    else:
        print(session["activity"])
    
    if "wallet" not in session:
        session["wallet"] = 0
    else:
        print(session["wallet"])

    return render_template("index.html")

@app.route('/clear')
def clear():

    session["wallet"] = 0
    session["activity"] = []
    return redirect("/")

@app.route('/process_money', methods=["POST"])
def addToWallet():
    print(request.form)

    if request.form["building"] == "farm":
        farmRand = random.randint(10,21)
        print farmRand
        session["wallet"] += farmRand
        print session["activity"]
        session["activity"].append("CONGRATS! You've earned " + str(farmRand) + " golds from the farm! " + str(datetime.now()) )

    if request.form["building"] == "cave":
        caveRand = random.randint(5,11)
        print caveRand
        session["wallet"] += caveRand
        session["activity"].append("CONGRATS! You've earned " + str(caveRand) + " golds from the cave! " + str(datetime.now()) )

    if request.form["building"] == "house":
        houseRand = random.randint(2,5)
        print houseRand
        session["wallet"] += houseRand
        session["activity"].append("CONGRATS! You've earned " + str(houseRand) + " golds from the house! " + str(datetime.now()) )

    if request.form["building"] == "casino":
        casinoRand = random.randint(0,51)
        if casinoRand == 0:
            session["activity"].append("You earned 0 golds" + str(datetime.now()) )
        if casinoRand % 2 == 1:
            print casinoRand
            session["wallet"] += casinoRand
            session["activity"].append("Yikes! You tried your luck at the casino and lost " + str(casinoRand) + " golds! " + str(datetime.now()) )
            
        else:
            print casinoRand
            session["wallet"] -= casinoRand
            session["activity"].append("CONGRATS! You've earned " + str(casinoRand) + " golds from the casino! " + str(datetime.now()) )

    return redirect("/")

app.run(debug=True)